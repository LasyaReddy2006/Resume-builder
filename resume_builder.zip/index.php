<?php
$errors = [];
$name = $email = $phone = $education = $skills = $experience = $languages = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  function clean_input($data) {
    return htmlspecialchars(trim($data));
  }

  $name = clean_input($_POST['name']);
  $email = clean_input($_POST['email']);
  $phone = clean_input($_POST['phone']);
  $education = clean_input($_POST['education']);
  $skills = clean_input($_POST['skills']);
  $experience = clean_input($_POST['experience']);
  $languages = clean_input($_POST['languages']);

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = "Invalid email format.";
  }

  if (!preg_match('/^[0-9]{10}$/', $phone)) {
    $errors['phone'] = "Phone must be 10 digits.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Simple Resume Builder</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js" defer></script>
</head>
<body>
  <form method="POST" action="" id="resumeForm">
    <h2>Enter Your Details</h2>
    <input type="text" name="name" placeholder="Full Name" value="<?= $name ?>" required>
    <input type="email" name="email" placeholder="Email" value="<?= $email ?>" required>
    <?php if (isset($errors['email'])) echo "<div class='error'>{$errors['email']}</div>"; ?>
    <input type="text" name="phone" placeholder="Phone" value="<?= $phone ?>" required>
    <?php if (isset($errors['phone'])) echo "<div class='error'>{$errors['phone']}</div>"; ?>
    <input type="text" name="education" placeholder="Education" value="<?= $education ?>" required>
    <textarea name="experience" placeholder="Experience" required><?= $experience ?></textarea>
    <textarea name="skills" placeholder="Skills (comma separated)" required><?= $skills ?></textarea>
    <textarea name="languages" placeholder="Languages Known" required><?= $languages ?></textarea>
    <button type="submit">Generate Resume</button>
  </form>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)): ?>
  <div id="resume">
    <h2><?= $name ?></h2>
    <p><strong>Email:</strong> <?= $email ?></p>
    <p><strong>Phone:</strong> <?= $phone ?></p>
    <p><strong>Education:</strong> <?= $education ?></p>
    <p><strong>Experience:</strong> <?= $experience ?></p>
    <p><strong>Skills:</strong> <?= $skills ?></p>
    <p><strong>Languages:</strong> <?= $languages ?></p>
  </div>
  <button onclick="downloadResume()">Download as PDF</button>
  <?php endif; ?>
</body>
</html>
