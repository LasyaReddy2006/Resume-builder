function downloadResume() {
  const content = document.getElementById('resume').innerHTML;
  const win = window.open('', '', 'height=700,width=700');
  win.document.write('<html><head><title>Resume</title></head><body>');
  win.document.write(content);
  win.document.write('</body></html>');
  win.document.close();
  win.print();
}
